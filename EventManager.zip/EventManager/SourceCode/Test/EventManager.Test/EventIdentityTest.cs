﻿using System;
using System.Linq;
using System.Collections.Generic;
using NUnit.Framework;
using EventManagerIdentity.API.Models;
using EventManagerIdentity.API.Services;
using Moq;

namespace EventManager.Test
{
    [TestFixture]
    public class EventIdentityTest
    {
        private IUserService _mockRepository;
        private List<User> _users;

        [SetUp]
        public void Initialize()
        {
            var repository = new Mock<IUserService>();
            
            _users = new List<User>() { 
                new User{ UserId = "1", UserName = "Admin", Password = "Test123", Role = "admin"}, 
                new User{ UserId = "2", UserName = "Emp1", Password = "Test123", Role = "employee"}, 
                new User{ UserId = "3", UserName = "Emp2", Password = "Test123", Role = "employee" }};

            // Get All trips by Employee Id
            repository.Setup(r => r.GetUser(It.IsAny<string>(), It.IsAny<string>()))
                .Returns((string i,string j) => _users.Where(t => t.UserId == i && t.Password == j).FirstOrDefault());

            _mockRepository = repository.Object;
        }

        [Test]
        public void Get_User_By_Credential()
        {
            User _user = _mockRepository.GetUser("3","Test123");
            Assert.IsTrue(_user.UserName == "Emp2");
        }

        [TearDown]
        public void CleanUp()
        {
            _users.Clear();
        }
    }
}
