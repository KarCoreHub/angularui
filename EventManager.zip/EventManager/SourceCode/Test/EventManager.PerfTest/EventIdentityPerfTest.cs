using System;
using System.Linq;
using System.Collections.Generic;
using NBench;
using Moq;
using EventManagerIdentity.API.Models;
using EventManagerIdentity.API.Services;


namespace EventManager.PerfTest
{
    public class EventIdentityPerfTest
    {
        private IUserService _mockRepository;
        private List<User> _users;

        [PerfSetup]
        public void Setup(BenchmarkContext context)
        {
            var repository = new Mock<IUserService>();

            _users = new List<User>() {
                new User{ UserId = "1", UserName = "Admin", Password = "Test123", Role = "admin"},
                new User{ UserId = "2", UserName = "Emp1", Password = "Test123", Role = "employee"},
                new User{ UserId = "3", UserName = "Emp2", Password = "Test123", Role = "employee" }};

            // Get All trips by Employee Id
            repository.Setup(r => r.GetUser(It.IsAny<string>(), It.IsAny<string>()))
                .Returns((string i, string j) => _users.Where(t => t.UserId == i && t.Password == j).FirstOrDefault());

            _mockRepository = repository.Object;
        }

        [PerfBenchmark(NumberOfIterations = 500, RunMode = RunMode.Iterations, TestMode = TestMode.Test, SkipWarmups = true)]
        [ElapsedTimeAssertion(MaxTimeMilliseconds = 100)]
        public void Get_User_500_Iterations()
        {
            _mockRepository.GetUser("2", "Test123");
        }

        [PerfBenchmark(NumberOfIterations = 1, RunMode = RunMode.Iterations, TestMode = TestMode.Test, SkipWarmups = true)]
        [ElapsedTimeAssertion(MaxTimeMilliseconds = 50)]
        public void Get_User_Elapsed_Time()
        {
            _mockRepository.GetUser("1", "Test123");
        }
    }
}

