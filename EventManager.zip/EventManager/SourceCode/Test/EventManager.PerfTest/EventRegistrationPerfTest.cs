using System;
using System.Linq;
using System.Collections.Generic;
using NBench;
using Moq;
using EventManagerRegistration.API.Models;
using EventManagerRegistration.API.Services;


namespace EventManager.PerfTest
{
    public class EventRegistrationPerfTest
    {
        private IEventService _mockRepository;
        private List<Event> _events;

        [PerfSetup]
        public void Setup(BenchmarkContext context)
        {

            var repository = new Mock<IEventService>();
            _events = new List<Event>()
                     {
                         new Event { EventId = "12479c13-afbd-4bec-ab3a-f5f7910328a0",EventName = "Vegetable Harvesting",EventDate =  new DateTime(2019,12,26), Venue = "Thiruvallur", VolunteerList = null, IsActive = true},
                         new Event { EventId = "2d05c0fe-d550-421e-bf2d-bf73af42c7bd",EventName = "Reserve Forest Clean up",EventDate =  new DateTime(2020,01,03), Venue = "Agaramthen",VolunteerList = null, IsActive = true},
                         new Event { EventId = "47bd9f7a-c3c1-4810-af75-6d12d395cf8a",EventName = "Be A Teacher",EventDate = new DateTime(2019,12,27), Venue = "Siruseri",VolunteerList = null, IsActive = true},
                     };

            //Get All
            repository.Setup(r => r.GetEvent()).Returns(_events);

            // Insert Event
            repository.Setup(r => r.Add(It.IsAny<Event>()))
                .Callback((Event p) => _events.Add(p));

            // Update Event
            repository.Setup(r => r.Update(It.IsAny<Event>())).Callback(
                (Event target) =>
                {
                    var original = _events.Where(
                        q => q.EventId == target.EventId).Single();

                    original.EventName = target.EventName;
                    original.EventDate = target.EventDate;
                    original.Venue = target.Venue;
                    original.VolunteerList = target.VolunteerList;
                    original.IsActive = target.IsActive;
                });

            _mockRepository = repository.Object;
        }

        [PerfBenchmark(NumberOfIterations = 500, RunMode = RunMode.Iterations, TestMode = TestMode.Test, SkipWarmups = true)]
        [ElapsedTimeAssertion(MaxTimeMilliseconds = 100)]
        public void Get_events_500_Iterations()
        {
            _mockRepository.GetEvent();
        }

        [PerfBenchmark(NumberOfIterations = 100, RunMode = RunMode.Iterations, TestMode = TestMode.Test, SkipWarmups = true)]
        [ElapsedTimeAssertion(MaxTimeMilliseconds = 100)]
        public void Add_events_100_Iterations()
        {
            Event e = new Event
            {
                EventId = new Guid().ToString(),
                EventName = "Awareness Wall Painting",
                EventDate = new DateTime(2019, 12, 27),
                Venue = "Velachery",
                VolunteerList = null,
                IsActive = true
            };
            _mockRepository.Add(e);
        }

        [PerfBenchmark(NumberOfIterations = 1, RunMode = RunMode.Iterations, TestMode = TestMode.Test, SkipWarmups = true)]
        [ElapsedTimeAssertion(MaxTimeMilliseconds = 50)]
        public void Get_events_Elapsed_Time()
        {
            _mockRepository.GetEvent();
        }

        [PerfBenchmark(NumberOfIterations = 1, RunMode = RunMode.Iterations, TestMode = TestMode.Test, SkipWarmups = true)]
        [ElapsedTimeAssertion(MaxTimeMilliseconds = 50)]
        public void Add_Events_Elapsed_Time()
        {
            Event e = new Event
            {
                EventId = new Guid().ToString(),
                EventName = "Awareness Wall Painting",
                EventDate = new DateTime(2019, 12, 27),
                Venue = "Velachery",
                VolunteerList = null,
                IsActive = true
            };
            _mockRepository.Add(e);
        }

        [PerfBenchmark(NumberOfIterations = 1, RunMode = RunMode.Iterations, TestMode = TestMode.Test, SkipWarmups = true)]
        [ElapsedTimeAssertion(MaxTimeMilliseconds = 50)]
        public void Update_Events_Elapsed_Time()
        {
            var eventId = "47bd9f7a-c3c1-4810-af75-6d12d395cf8a";
            List<string> userList = new List<string> { "Rohit Prabu(211511)", "Rithika P(234567)" };

            Event e = new Event
            {
                EventId = eventId,
                EventName = "Be A Teacher",
                EventDate = new DateTime(2019, 12, 27),
                Venue = "Siruseri",
                VolunteerList = userList,
                IsActive = true
            };
            _mockRepository.Update(e);
        }
    }
}

