﻿using System;
using System.Collections.Generic;
using System.Text;
using EventManagerRegistration.API.Models;
using System.Threading.Tasks;


namespace EventManagerRegistration.API.Services

{
    public interface IEventService
    {
        Task Add(Event eventObj);
        Task Update(Event eventObj);
        IEnumerable<Event> GetEvent();
    }
}
