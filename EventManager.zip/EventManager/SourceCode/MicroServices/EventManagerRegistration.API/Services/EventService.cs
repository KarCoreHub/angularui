﻿using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using EventManagerRegistration.API.Models;
using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.Model;
using System.Threading.Tasks;

namespace EventManagerRegistration.API.Services
{
    public class EventService : IEventService
    {
        private const string TableName = "Events";
        private readonly IAmazonDynamoDB _context;


        public EventService(IAmazonDynamoDB context)
        {
            _context = context;
        }

        public async Task Add(Event e)
        {
            var queryRequest = RequestBuilder(e,"Add");
            await PutItemAsync(queryRequest);
        }

        public async Task Update(Event e)
        {
            var queryRequest = RequestBuilder(e,"Update");
            await PutItemAsync(queryRequest);
        }
      
        private PutItemRequest RequestBuilder(Event e,string action)
        {
            string volunteerList = "[]";
            string eventId = "";
            if (action == "Add")
            {
                eventId = Guid.NewGuid().ToString();
            }
            else
            {
                eventId = e.EventId;
                e.VolunteerList = e.VolunteerList.OrderBy(r => r).ToList();
                volunteerList = JsonConvert.SerializeObject(e.VolunteerList).ToString();
            }
            
            var item = new Dictionary<string, AttributeValue>
            {
                {"Id", new AttributeValue {S = eventId}},
                {"EventName", new AttributeValue {S = e.EventName}},
                {"Venue", new AttributeValue {S = e.Venue}},
                {"EventDate", new AttributeValue {S = e.EventDate.ToString()}},
                {"VolunteerList", new AttributeValue {S = volunteerList}},
                {"IsActive", new AttributeValue {S = "True"}}
            };

            return new PutItemRequest
            {
                TableName = TableName,
                Item = item
            };
        }

        private async Task PutItemAsync(PutItemRequest request)
        {
            await _context.PutItemAsync(request);
        }

        public IEnumerable<Event> GetEvent()
        {
            return GetEventData().Result;
        }
            public async Task<IEnumerable<Event>> GetEventData()
        {
            ScanRequest request = new ScanRequest
            {
                TableName = TableName,
                ExpressionAttributeValues = new Dictionary<string, AttributeValue>
                {
                     { ":v_active", new AttributeValue { S= "True" } }
                },
                FilterExpression = "IsActive= :v_active"
            };

            ScanResponse response = await _context.ScanAsync(request);
            return response.Items.Select(Map).ToList();
        }
        private Event Map(Dictionary<string, AttributeValue> result)
        {
            return new Event
            {
                EventId = result["Id"].S,
                EventName = result["EventName"].S,
                Venue = result["Venue"].S,
                EventDate = Convert.ToDateTime(result["EventDate"].S),
                VolunteerList = JsonConvert.DeserializeObject<List<string>>(result["VolunteerList"].S),
                IsActive = Convert.ToBoolean(result["IsActive"].S)
            };
        }
    }
}
