using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace EventManagerRegistration.API.Models
{
    public class ErrorModel
    {
        public int StatusCode { get; set; }
        public string Message { get; set; }

    }
}