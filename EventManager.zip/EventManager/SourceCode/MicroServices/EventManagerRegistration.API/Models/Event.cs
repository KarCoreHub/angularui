using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EventManagerRegistration.API.Models
{
    public class Event
    {
        public string EventId { get; set; }
        public string EventName { get; set; }
        public string Venue { get; set; }
        public DateTime EventDate { get; set; }
        public List<string> VolunteerList { get; set; }
        public bool IsActive { get; set; }
    }
}
