﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using EventManagerRegistration.API.Models;
using EventManagerRegistration.API.Services;
using EventManagerRegistration.API.Middleware;

namespace EventManagerRegistration.API.Controllers
{
    [Authorize]
    [Route("api/event")]
    [ApiController]

    public class EventController : ControllerBase
    {
        private readonly IEventService _eventService;
        private ILoggerManager _logger;
        public EventController(IEventService Service, ILoggerManager logger)
        {
            _eventService = Service;
            _logger = logger;
        }

        [Route("AddEvent")]
        public IActionResult AddEvent([FromBody] Event e)
        {
            _logger.LogInformation("Calling Add Function to create new event");
            _eventService.Add(e);
            return Ok(1);
        }

        [Route("UpdateEvent")]
        public IActionResult UpdateEvent([FromBody] Event e)
        {
            _logger.LogInformation("Calling Update Function to create new event");
            _eventService.Update(e);
            return Ok(1);
        }



        [Route("GetEvent")]        
        public IActionResult GetEvent()
        {
            IEnumerable<Event> events = _eventService.GetEvent();
            return Ok(events);
        }
    }
}

