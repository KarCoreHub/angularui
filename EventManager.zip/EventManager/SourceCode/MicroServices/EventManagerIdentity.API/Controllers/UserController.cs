﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.IdentityModel.Tokens;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using EventManagerIdentity.API.Models;
using EventManagerIdentity.API.Services;
using EventManagerIdentity.API.Middleware;


namespace EventManagerIdentity.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [AllowAnonymous]
    public class UserController : ControllerBase
    {
        private readonly IUserService _userService;
        private ILoggerManager _logger;
        public const string SessionKeyName = "FailCounts";

        public UserController(IUserService Service,ILoggerManager logger)
        {
            _userService = Service;
            _logger = logger;
        }

        [HttpPost("Authenticate")]
        public IActionResult Authenticate([FromBody] User user)
        {
            
            _logger.LogInformation("Authenticating the User");
            var users = _userService.GetUser(user.UserId, user.Password);

            if (users == null)
            {
                //Logging the Number of Failure Attempts in Authentication 
                if (string.IsNullOrEmpty(HttpContext.Session.GetString(SessionKeyName)))
                {
                    HttpContext.Session.SetInt32(SessionKeyName, 0);
                }
                int failcount = Convert.ToInt32(HttpContext.Session.GetInt32(SessionKeyName))+1;
                HttpContext.Session.SetInt32(SessionKeyName, failcount);
                _logger.LogInformation($"Authentication Failure Attempts in the Session:{failcount}");

                //Return Login Failure Token
                return Ok(new { Token = "", Usertype = "0" });
            }
            else
            {
               //Generating Token for Successful Authentication
                var claims = new[] { new Claim(ClaimTypes.Name, users.UserId) };

                var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("MySecretTokenForJwt"));

                var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha512Signature);

                var tokenDescriptor = new SecurityTokenDescriptor
                {
                    Subject = new ClaimsIdentity(claims),
                    Expires = DateTime.Now.AddDays(1),
                    SigningCredentials = creds
                };

                var tokenHandler = new JwtSecurityTokenHandler();
                var token = tokenHandler.CreateToken(tokenDescriptor);

                return Ok(new { token = tokenHandler.WriteToken(token), Userid = users.UserId, Username = users.UserName, Usertype = users.Role });
            }
        }
      
    }
    
}
