﻿using System;
using System.Collections.Generic;
using System.Text;
using EventManagerIdentity.API.Models;

namespace EventManagerIdentity.API.Services
{
    public interface IUserService
    {
        User GetUser(string UserId, string Password);
    }
}
