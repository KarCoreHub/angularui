﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EventManagerIdentity.API.Models;
using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.Model;
using System.Threading.Tasks;

namespace EventManagerIdentity.API.Services
{
    public class UserService : IUserService
    {
        private const string TableName = "User";
        private readonly IAmazonDynamoDB _context;

        public UserService(IAmazonDynamoDB context)
        {
            _context = context;
        }

        public User GetUser(string UserId, string Password)
        {
            return GetUserData(UserId, Password).Result;
        }
        private async Task<User> GetUserData(string UserId, string Password)
        {
            ScanRequest request = new ScanRequest
            {
                TableName = TableName,
                ExpressionAttributeValues = new Dictionary<string, AttributeValue>
                {
                     { ":v_user", new AttributeValue { S= UserId.ToString() } },
                     { ":v_pass", new AttributeValue { S= Password.ToString() } },
                },
                FilterExpression = "Id= :v_user and Password=:v_pass"
            };

            ScanResponse response = await _context.ScanAsync(request);
            return response.Items.Select(Map).FirstOrDefault();
        }
        private User Map(Dictionary<string, AttributeValue> result)
        {
            return new User
            {
                UserId = result["Id"].S,
                UserName = result["Username"].S,
                Password = "",
                Email = result["Email"].S,
                Role = result["Role"].S
            };
        }
    }
}
