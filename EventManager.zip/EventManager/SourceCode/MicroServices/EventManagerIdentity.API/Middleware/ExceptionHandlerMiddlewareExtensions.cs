﻿using System;
using Microsoft.AspNetCore.Builder;

namespace EventManagerIdentity.API.Middleware
{
    public static class ExceptionHandlerMiddlewareExtensions
    {
        public static void CustomExceptionMiddleware(this IApplicationBuilder app)
        {
            app.UseMiddleware<ExceptionHandlerMiddleware>();
        }
    }
}
