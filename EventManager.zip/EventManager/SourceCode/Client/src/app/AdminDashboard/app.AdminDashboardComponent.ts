import { Component} from '@angular/core';

@Component({
    templateUrl:'./app.AdminDashboardComponent.html'
    ,styleUrls: ['./../_layout/app-adminlayout.component.css']
})

export class AdminDashboardComponent
{


}