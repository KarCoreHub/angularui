import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { EventModel } from '../Models/app.EventModel';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { throwError } from 'rxjs';
import { catchError, tap } from 'rxjs/operators'

@Injectable({
  providedIn: 'root'
})
export class EventService {

  
  private data: any;
  token: any;
 
  constructor(private _http: HttpClient, private _Route: Router) 
  {
    if(sessionStorage.getItem('currentUser')!= null)
    this.data = JSON.parse(sessionStorage.getItem('currentUser'));
    else
    this.data = JSON.parse(sessionStorage.getItem('AdminUser'));
    this.token = this.data.token;
 }

  apiUrl: string = `${environment.apiEndpoint}/event/`;

  public createEvent(eventmodel: EventModel)
  {
        var getUrl = this.apiUrl + "AddEvent";
        let headers = new HttpHeaders({ 'Content-Type': 'application/json' });  
        headers = headers.append('Authorization', 'Bearer ' + `${this.token}`);      
        return this._http.post<any>(getUrl, eventmodel, { headers: headers })
        .pipe(tap(data =>
        {
            console.log(data);
            if (data != null)
            {
                // return 1 to indicate successful creation of events
                return 1;
            } else {
                // return null to indicate failure
                return null;
            }
        }),
            catchError(this.handleError)
        );
}

private handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
        // A client-side or network error occurred. Handle it accordingly.
        console.error('An error occurred:', error.error.message);
    } else {
        // The backend returned an unsuccessful response code.
        // The response body may contain clues as to what went wrong,
        console.error(`Backend returned code ${error.status}, ` + `body was: ${error.error}`);
    }
    // return an observable with a user-facing error message
    return throwError('Something bad happened; please try again later.');
};
}
