import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EventModel } from './Models/app.EventModel';
import { EventService } from './Services/app.EventService';
import { MatDialog,MatDialogRef } from '@angular/material';
import { InfoDialogComponent } from '../infodialog/infodialog.component';

@Component({
  templateUrl: './addevent.component.html'
})

export class AddEventComponent implements OnInit {

  ngOnInit(): void {
  }
  private _eventservice;
  IsValid:boolean

  constructor(private _Route: Router, eventservice: EventService,public dialog: MatDialog) {
    this._eventservice = eventservice;
    this.IsValid = false;
  }

  EventData: EventModel = new EventModel();

  openDialog(message:string) {
    const dialogRef = this.dialog.open(InfoDialogComponent, {
      width: '400px',
      data: { message:message }
    });
  }
  
  validateForm()
  {
    if(this.EventData.eventname == undefined  || this.EventData.eventname == "")
    {
      this.openDialog("Please enter eventname");
      return false;
    }
    if(this.EventData.eventdate == undefined  || this.EventData.eventdate == "")
    {
      this.openDialog("Please enter eventdate");
      return false;
    }
    if(this.EventData.venue == undefined  || this.EventData.venue == "")
    {
      this.openDialog("Please enter venue");
      return false;
    }
    return true;
  }

  onSubmit() {
    this.IsValid = this.validateForm();
    if(this.IsValid)
    {
      this._eventservice.createEvent(this.EventData).subscribe(
      response => {
        if (response != null)
        {
          //this.openDialog("Event Created Successfully!");
          this._Route.navigate(['/Admin/View']);
        }
      });
    }
  }
}
