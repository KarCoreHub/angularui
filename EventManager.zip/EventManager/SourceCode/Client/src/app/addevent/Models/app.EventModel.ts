export class EventModel {
    eventid: string;
    eventname: string;
    eventdate: any;
    venue:string;
}
