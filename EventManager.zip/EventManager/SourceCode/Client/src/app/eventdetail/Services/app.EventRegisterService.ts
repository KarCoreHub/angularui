import { Injectable } from '@angular/core';
import { Observable, of,throwError } from 'rxjs'
import { map, catchError, tap, mergeMap, materialize, dematerialize } from 'rxjs/operators';
import { HttpClient, HttpHeaders, HttpErrorResponse, HttpResponse } from '@angular/common/http';
import {environment} from '../../../environments/environment';

@Injectable({ providedIn: 'root' })

export class EventRegisterService {

    private data: any;
    private apiUrl = environment.apiEndpoint + '/event';
    token: any;
    usertype: any;
    userId: number;


    constructor(private http: HttpClient) {
        if(sessionStorage.getItem('currentUser')!= null)
        this.data = JSON.parse(sessionStorage.getItem('currentUser'));
        else
        this.data = JSON.parse(sessionStorage.getItem('AdminUser'));
        this.token = this.data.token;
    }

        updateEvent (event:any): Observable<any> {
            let getUrl = this.apiUrl+"/UpdateEvent";
            let headers = new HttpHeaders({ 'Content-Type': 'application/json' });  
            headers = headers.append('Authorization', 'Bearer ' + `${this.token}`); 
            return this.http.put(getUrl, JSON.stringify(event), { headers: headers }).pipe(
              tap(res => {
               return res;
          }),
              catchError(this.handleError<any>('updateJson'))
            );
          }
    
      getEvents (): Observable<any> {
        let getUrl = this.apiUrl+"/GetEvent";  
        let headers = new HttpHeaders({ 'Content-Type': 'application/json' });  
        headers = headers.append('Authorization', 'Bearer ' + `${this.token}`); 
        return this.http.get<any>(getUrl,{ headers: headers }).pipe(
          tap(res => {
           return res;
      }),
          catchError(this.handleError<any>('updateJson'))
        );
      }

    private handleError<T>(operation = 'operation', result?: T) {
        return (error: any): Observable<T> => {
            console.log(`${operation} failed: ${error.message}`);
            return of(result);
        };
    }
}
