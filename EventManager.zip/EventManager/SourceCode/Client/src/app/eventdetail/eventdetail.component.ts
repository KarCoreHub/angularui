import { Component, OnInit, ViewChild, Inject} from '@angular/core';
import { Router } from '@angular/router';
import { EventRegisterService } from './Services/app.EventRegisterService';
import { MatSort, MatPaginator, MatTableDataSource, MatDialog, MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { ConfirmDialogComponent } from '../confirmdialog/confirmdialog.component';

@Component({
  selector: 'app-eventdetail',
  templateUrl: './eventdetail.component.html'
})
export class EventDetailComponent implements OnInit {
  dataSource: any;
  displayedColumns: string[];
  user: any;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild(MatPaginator,{ static: true }) paginator: MatPaginator;

  constructor(private router: Router, private eventRegisterService: EventRegisterService, public dialog: MatDialog) { }

  ngOnInit() {
    this.user = JSON.parse(sessionStorage.getItem('currentUser'));
    if(this.user==null)
    {
      this.user=JSON.parse(sessionStorage.getItem('AdminUser'));
    }
    this.getEvents();
  }

  getEvents() {
    this.eventRegisterService.getEvents().subscribe(
      response => {
        console.log(response);        
        if (this.user.usertype == "admin") {
          this.displayedColumns = ["eventName", "venue", "eventDate", "volunteerList"];
        }
        else {
          this.displayedColumns = ["eventName", "venue", "eventDate", "action"];
        }
        this.dataSource = new MatTableDataSource(response);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      });
  }

  checkUserExists(event:any) {
    if (event.volunteerList && event.volunteerList.length > 0) {
      return event.volunteerList.toString().indexOf(this.user.userid) > -1;
    }
    else {
      return false;
    }
  }

  doFilter(value:any) {
    this.dataSource.filter = value.trim().toLocaleLowerCase();
  }

  openDialog(event:any) {
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      width: '480px',
      data: { event: event }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result && typeof(result) != undefined) {
        this.registerEvent(result.event);
      }
    });
  }

  registerEvent(event:any) {
    var user = this.user;
    if (user) {
      if (event.volunteerList && event.volunteerList.length > 0) {
        event.volunteerList.push(user.username + " (" + user.userid + ")");
      }
      else {
        event.volunteerList = [user.username + " (" + user.userid + ")"];
      }
      this.eventRegisterService.updateEvent(event).subscribe(
        response => {
          this.getEvents();
        });
    }
  }

}