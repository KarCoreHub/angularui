import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material';
import { LoginModel } from './Models/app.LoginModel';
import { LoginService } from './Services/app.LoginService';
import { InfoDialogComponent } from '../infodialog/infodialog.component';


@Component({
  templateUrl: './login.component.html'
})

export class LoginComponent implements OnInit {

  ngOnInit(): void {
    sessionStorage.clear();
  }
  private _loginservice;
  IsValid:boolean

  constructor(private _Route: Router, loginservice: LoginService,public dialog: MatDialog) {
    this._loginservice = loginservice;
    this.IsValid = false;
  }

  LoginData: LoginModel = new LoginModel();
  
  openDialog(message:string) {
    this.dialog.open(InfoDialogComponent, {
      width: '400px',
      data: { message:message }
    });
  }

  validateForm()
  {
    if(this.LoginData.UserId == undefined  || this.LoginData.UserId == "")
    {
      this.openDialog("Please enter username");
      return false;
    }
    if(this.LoginData.Password == undefined  || this.LoginData.Password == "")
    {
      this.openDialog("Please enter password");
      return false;
    }
    return true;
  }
  onSubmit() {

    this.IsValid = this.validateForm();
    if(this.IsValid)
    {
      this._loginservice.validateLoginUser(this.LoginData).subscribe(
      response => {
        if (response == null || (response.token == "" && response.usertype == "0")) {
          this.openDialog("Invalid Username or Password");
        }

        if (response.usertype == "admin") {
              this._Route.navigate(['/Admin/Dashboard']);
        }

        if (response.usertype == "employee") {
              this._Route.navigate(['/User/Dashboard']);
        }
      });
    }
  }
}
