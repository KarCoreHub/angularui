export class LoginModel
{
    UserId:string;
    UserName: string;
    Password: string; 
    Role: string;
}