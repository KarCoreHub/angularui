import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-app-layout',
  templateUrl: './app-admin-layout.component.html',
  styleUrls: ['./app-adminlayout.component.css']
})
export class AppAdminLayoutComponent implements OnInit 
{
  screenWidth: number;
  data: any;
  constructor() {
    // set screenWidth on page load
    this.screenWidth = window.innerWidth;
    window.onresize = () => {
      // set screenWidth on screen size change
      this.screenWidth = window.innerWidth;
    };
  }
   ngOnInit(){
    this.data = JSON.parse(sessionStorage.getItem('AdminUser'));
    console.log(this.data);

   }
}
