import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { AppAdminLayoutComponent } from './_layout/app-adminlayout.component';
import { AppUserLayoutComponent } from './_layout/app-userlayout.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NavigationComponent } from './navigation/navigation.component';
import {RouterModule, Routes} from '@angular/router';
import {CustomMaterialModule} from './core/material.module';
import { LoginComponent } from './login/login.component';
import { AddEventComponent } from './addevent/addevent.component';
import { EventDetailComponent } from './eventdetail/eventdetail.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AdminLogoutComponent } from './login/app.AdminLogout.Component';
import { UserLogoutComponent } from './login/app.UserLogout.Component';
import { AdminAuthGuardService } from './AuthGuard/AdminAuthGuardService';
import { UserAuthGuardService } from './AuthGuard/UserAuthGuardService';
import { UserDashboardComponent } from './UserDashboard/app.UserDashboardComponent';
import { AdminDashboardComponent } from './AdminDashboard/app.AdminDashboardComponent';
import { InfoDialogComponent } from './infodialog/infodialog.component';
import { ConfirmDialogComponent } from './confirmdialog/confirmdialog.component';
import { LoginService } from './login/Services/app.LoginService';
import { EventService } from './addevent/Services/app.EventService';
import { EventRegisterService } from './eventdetail/Services/app.EventRegisterService';
import {NgxPaginationModule} from 'ngx-pagination';
import { FilterPipe } from './Shared/filter.pipe';
import { OrderByPipe } from './Shared/orderby.pipe';

@NgModule({
  declarations: [
    AppComponent,
    AppAdminLayoutComponent,
    AppUserLayoutComponent,
    LoginComponent,
    AddEventComponent,
    EventDetailComponent,
    AdminLogoutComponent,
    UserLogoutComponent,
    UserDashboardComponent,
    AdminDashboardComponent,
    InfoDialogComponent,
    ConfirmDialogComponent,
    NavigationComponent,    
    OrderByPipe,
    FilterPipe
  ],
  imports: [
    BrowserModule,
    CustomMaterialModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    HttpClientModule,
    CustomMaterialModule,
    NgxPaginationModule,
    RouterModule.forRoot([
      {
        path: 'Admin',
        component: AppAdminLayoutComponent,
        children: [
          { path: 'Dashboard', component: AdminDashboardComponent, canActivate: [AdminAuthGuardService] },
          { path: 'Add', component: AddEventComponent, canActivate: [AdminAuthGuardService] },
          { path: 'View', component: EventDetailComponent, canActivate: [AdminAuthGuardService] }
        ]
      },
      {
        path: 'User',
        component: AppUserLayoutComponent,
        children: [
          { path: 'Dashboard', component: UserDashboardComponent, canActivate: [UserAuthGuardService] }, 
          { path: 'View', component: EventDetailComponent, canActivate: [UserAuthGuardService] }
        ]
      },

      { path: 'Login', component: LoginComponent },
      { path: 'AdminLogout', component: AdminLogoutComponent },
      { path: 'UserLogout', component: UserLogoutComponent },

      { path: '', redirectTo: "Login", pathMatch: 'full' },
      { path: '**', redirectTo: "Login", pathMatch: 'full' },


    ])
  ],
  entryComponents: [InfoDialogComponent,ConfirmDialogComponent],
  providers: [AdminAuthGuardService, UserAuthGuardService,LoginService,EventService,EventRegisterService],
  bootstrap: [AppComponent]
})
export class AppModule { }
