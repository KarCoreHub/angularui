﻿import { Pipe, PipeTransform } from '@angular/core';
@Pipe({
    name: 'filter'
})
export class FilterPipe implements PipeTransform {
    transform(items: any[], searchText: string): any[] {
        if (!items) return [];
        if (!searchText) return items;
        return items.filter(it => {
                searchText = searchText.toLowerCase();
                return ((it.tripTakenBy != null && it.tripTakenBy.toLowerCase().includes(searchText.toLowerCase()))
                    || (it.StartTime != null && it.StartTime == searchText)
                    || (it.EndTime != null && it.EndTime == searchText));
        });
    }
}