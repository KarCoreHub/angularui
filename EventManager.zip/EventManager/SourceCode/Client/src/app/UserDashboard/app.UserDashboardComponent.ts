import { Component} from '@angular/core';

@Component({
    templateUrl:'./app.UserDashboardComponent.html'
    ,styleUrls: ['./../_layout/app-adminlayout.component.css']
})

export class UserDashboardComponent
{

}