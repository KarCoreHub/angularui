import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import {
   MatButtonModule,
   MatToolbarModule,
   MatIconModule,
   MatBadgeModule,
   MatSidenavModule,
   MatListModule,
   MatGridListModule,
   MatFormFieldModule,
   MatInputModule,
   MatProgressSpinnerModule,
   MatSnackBarModule,
   MatSelectModule,
   MatRadioModule,
   MatCheckboxModule,
   MatDatepickerModule,
   MatNativeDateModule,
   MatChipsModule,
   MatTooltipModule,
   MatTableModule,
   MatSortModule,
   MatPaginatorModule,
   MatCardModule,
   MatDialogModule
} from '@angular/material';

@NgModule({
   imports: [
      CommonModule,
      MatButtonModule,
      MatToolbarModule,
      MatIconModule,
      MatSidenavModule,
      MatBadgeModule,
      MatListModule,
      MatGridListModule,
      MatFormFieldModule,
      MatInputModule,
      MatProgressSpinnerModule,
      MatSnackBarModule,
      MatSelectModule,
      MatRadioModule,
      MatCheckboxModule,
      MatDatepickerModule,
      MatNativeDateModule,
      MatChipsModule,
      MatTooltipModule,
      MatTableModule,
      MatPaginatorModule,
      MatSortModule,
      MatCardModule,
      MatDialogModule
   ],
   exports: [
      MatButtonModule,
      MatToolbarModule,
      MatIconModule,
      MatSidenavModule,
      MatBadgeModule,
      MatListModule,
      MatGridListModule,
      MatInputModule,
      MatProgressSpinnerModule,
      MatSnackBarModule,
      MatFormFieldModule,
      MatSelectModule,
      MatRadioModule,
      MatCheckboxModule,
      MatDatepickerModule,
      MatChipsModule,
      MatTooltipModule,
      MatTableModule,
      MatPaginatorModule,
      MatSortModule,
      MatCardModule,
      MatDialogModule
   ],
   providers: [
      MatDatepickerModule,
   ]
})

export class CustomMaterialModule { }