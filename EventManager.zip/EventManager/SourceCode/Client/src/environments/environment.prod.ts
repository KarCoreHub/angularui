export const environment = {
  production: true,
  
apiEndpoint: 'http://event-gateway-1128946116.us-east-2.elb.amazonaws.com'};
