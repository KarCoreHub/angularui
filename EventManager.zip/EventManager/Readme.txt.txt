Setting up Consul: 
 Download consul from the website https://releases.hashicorp.com/consul/0.5.2/
 Use command "consul agent -dev" to instantiate Consul 

Setting up the Client: 
 Open another command prompt and locate to EventManager\SourceCode\Client path
 Run command npm install and ng add @angular/material to install dependencies
 Open the VMS Application using "ng serve -o" command

Setting up the services: 
 Verify the Consul is up in the url http://localhost:8500
 Open the three projects in three visual studio to run each one of them as an individual service
    1)APIGateway\EventManagerGateway.API\
    2)MicroServices\EventManagerIdentity.API\
    3)MicroServices\EventManagerRegistration.API\
 Run all three projects. 
 
Validating Service Url: 
 Service 1 will open in http://localhost:9000 
 Service 2 will open in http://localhost:9001
 Service 3 will open in http://localhost:9002 
 The pages may show localhost page can't found or any other message. It is not an issue and the service will respond once the request is made to it.

The Microservices "EventIdentityService" and "EventRegistrationService" will be displayed in Consul Services.
Modify the EventManagerGateway configuration to use the Consul services.

Vulnerability Check: 
Add Security Code Scan extension in Visual studio and Run Code Analysis. 

AWS VMS Application URL:
http://eventmanagerapp-bucket.s3-website.us-east-2.amazonaws.com/

 Username and Password for Login Credentials:

 Admin     => Username:211202 , Password:Test123
 Employee1 => Username:211511 , Password:Test123
 Employee2 => Username:234567 , Password:Test123  



  

